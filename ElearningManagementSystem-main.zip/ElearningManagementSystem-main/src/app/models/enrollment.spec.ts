import { Enrollment } from './enrollment';

describe('Enrollment', () => {
  it('should create an instance', () => {
    expect(new Enrollment()).toBeTruthy();
  });
});
