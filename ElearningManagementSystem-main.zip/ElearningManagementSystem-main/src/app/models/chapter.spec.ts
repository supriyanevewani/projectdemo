import { Chapter } from './chapter';

describe('Chapter', () => {
  it('should create an instance', () => {
    expect(new Chapter()).toBeTruthy();
  });
});
